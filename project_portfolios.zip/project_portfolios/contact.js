// img localisation

function img1_over(element){
    var img1=document.querySelector(".img1");
    img1.src="./images/icons8-adresse-50.png";
}
function img1_out(element){
    var img1=document.querySelector(".img1");
    img1.src="./images/icons8-adresse-50 (1).png";
}

// img message

function img2_over(element){
    var img1=document.querySelector(".img2");
    img1.src="./images/icons8-points-enveloppe-50.png";
}
function img2_out(element){
    var img1=document.querySelector(".img2");
    img1.src="./images/icons8-message-50.png";
}

// img phone

function img3_over(element){
    var img1=document.querySelector(".img3");
    img1.src="./images/icons8-android-501.png";
}
function img3_out(element){
    var img1=document.querySelector(".img3");
    img1.src="./images/icons8-android-50.png";
}